def parse_tsp(filename):
    f = open(filename, 'r')
    data = f.read().split('\n')
    for k in range(len(data)):
        if data[k] == 'NODE_COORD_SECTION':
            break
    
    city_coord = {}
    for i in range(k+1,len(data)):
        if data[i] != '':
            city = data[i].split()
            city_coord[int(city[0])-1] = {'X': float(city[1]), 'Y': float(city[2])}

    return city_coord

def parse_tsp_list(filename):
    f = open(filename, 'r')
    data = f.read().split('\n')
    for k in range(len(data)):
        if data[k] == 'NODE_COORD_SECTION':
            break
    
    city_coord = []
    for i in range(k+1,len(data)):
        if data[i] != '':
            city = data[i].split()
            city_coord.append((float(city[1]), float(city[2])))

    return city_coord

# filename = "dj38.tsp"
# city_coord_dict = parse_tsp(filename)
# city_coord_list = parse_tsp_list(filename)
