from tsp_cities import *
import numpy as np
import math
import copy

def init_population(city_nb, size=10000):
    population = []
    for i in range(size):
        ind = np.random.permutation(city_nb)
        population.append(ind)
        
    return population
    
def evaluation(data, ind):
    dist = 0
    for i in range(len(ind)-1):
        dist += math.sqrt((data[ind[i]][0] - data[ind[i+1]][0]) ** 2 + (data[ind[i]][1] - data[ind[i+1]][1]) ** 2)
        
    dist += math.sqrt((data[ind[-1]][0] - data[ind[0]][0]) ** 2 + (data[ind[-1]][1] - data[ind[0]][1]) ** 2)
    
    return dist
    
def eval_pop(data, pop):
    for i in range(len(pop)):
        pop[i] = (pop[i], evaluation(data, pop[i]))

def tournament_select(pop, k=5):
    random_select = np.random.choice(a=np.arange(len(pop)), size=k, replace=False)
    tournament_pop = pop.pop(min(random_select))

    return tournament_pop[0]

def crossover(ind1, ind2):
    cx_point = np.random.randint(len(ind1))
    offspring1 = ind1[:cx_point]
    for elem in ind2:
        if elem not in offspring1:
            offspring1 = np.append(offspring1, elem)

    offspring2 = ind2[:cx_point]
    for elem in ind1:
        if elem not in offspring2:
            offspring2 = np.append(offspring2, elem)

    return (offspring1, offspring2)

def mutation(ind):
    mut_points = np.random.choice(a=np.arange(len(ind)), size=2, replace=False)
    ind[mut_points[0]], ind[mut_points[1]] = ind[mut_points[1]], ind[mut_points[0]]

def merge_pop(current_pop, next_pop, pop_size, elite_ratio=0.9):
    current_pop.extend(next_pop)
    current_pop.sort(key=lambda x: x[1])
    elite_size = int(pop_size*elite_ratio)
    new_pop = current_pop[:elite_size] + current_pop[-(pop_size-elite_size):]
    return new_pop

def ga():
    # Input data
    data = parse_tsp_list("dj38.tsp")
    city_nb = len(data)

    # Parameters
    P_C = 1
    P_M = 0.3
    MAX_ITER = 10000
    MAX_NOCHANGE = 1000
    POP_SIZE = 100
    MU = 50

    # Init pop
    rand_pop = init_population(city_nb)
    eval_pop(data, rand_pop)
    rand_pop.sort(key=lambda x: x[1])
    current_pop = rand_pop[:POP_SIZE]
    current_best = current_pop[0][1]

    # Evolution
    i = 0
    nochange_iter = 0
    while i <= MAX_ITER and nochange_iter <= MAX_NOCHANGE:
        print("Iteration", i, "Best", current_best)
        # Parent selection
        select_pop = copy.deepcopy(current_pop)
        parent_pop = []
        while len(parent_pop) < MU:
            parent_pop.append(tournament_select(select_pop))
        
        # Offspring creation
        next_pop = []
        for p in range(len(parent_pop)-1):
            parent1 = parent_pop[p]
            parent2 = parent_pop[p+1]
            # Crossover
            if np.random.rand() <= P_C:
                offsprings = crossover(parent1, parent2)

                # Mutation
                for child in offsprings:
                    if np.random.rand() <= P_M:
                        mutation(child)

                next_pop.extend(offsprings)

        # New population evaluation
        eval_pop(data, next_pop)

        # Population merge
        current_pop = merge_pop(current_pop, next_pop, POP_SIZE)

        # Optional: termination criterion based on unchanged best
        if current_pop[0][1] >= current_best:
            nochange_iter += 1
        else:
            current_best = current_pop[0][1]
            nochange_iter = 0
            
        i += 1

    return current_pop[0]

best_sol = ga()
print(best_sol)
    