from tsp_cities import *
import numpy as np
import math

from deap import algorithms
from deap import base
from deap import creator
from deap import tools

def random_ind(city_nb):
    return list(np.random.permutation(city_nb))

def evaluation(data, ind):
    dist = 0
    for i in range(len(ind)-1):
        dist += math.sqrt((data[ind[i]][0] - data[ind[i+1]][0]) ** 2 + (data[ind[i]][1] - data[ind[i+1]][1]) ** 2)

    dist += math.sqrt((data[ind[-1]][0] - data[ind[0]][0]) ** 2 + (data[ind[-1]][1] - data[ind[0]][1]) ** 2)

    return dist,

def crossover(ind1, ind2):
    cx_point = np.random.randint(len(ind1))
    offspring1 = ind1[:cx_point]
    for elem in ind2:
        if elem not in offspring1:
            offspring1.append(elem)

    offspring2 = ind2[:cx_point]
    for elem in ind1:
        if elem not in offspring2:
            offspring2.append(elem)

    return (creator.Individual(offspring1), creator.Individual(offspring2))

def mutation(ind):
    mut_points = np.random.choice(a=np.arange(len(ind)), size=2, replace=False)
    ind[mut_points[0]], ind[mut_points[1]] = ind[mut_points[1]], ind[mut_points[0]]

    return ind,

def ga():
    # Input data
    data = parse_tsp_list("dj38.tsp")
    city_nb = len(data)

    # Parameters
    INIT_SIZE = 1000
    P_C = 0.7
    P_M = 0.3
    MAX_ITER = 10000

    # DEAP Init
    creator.create("Fitness", base.Fitness, weights=(-1.0,))
    creator.create("Individual", list, fitness=creator.Fitness)

    toolbox = base.Toolbox()

    toolbox.register("attr_item", random_ind, city_nb)

    toolbox.register("individual", tools.initIterate, creator.Individual, toolbox.attr_item)
    toolbox.register("population",  tools.initRepeat, list, toolbox.individual)

    toolbox.register("evaluate", evaluation, data)
    toolbox.register("mate", crossover)
    toolbox.register("mutate", mutation)
    toolbox.register("select", tools.selTournament, tournsize=5)

    # Init pop
    pop = toolbox.population(n=INIT_SIZE)

    # Hall of fame and evolution statistics
    hof = tools.HallOfFame(1)
    stats = tools.Statistics(lambda ind: ind.fitness.values)
    stats.register("avg", np.mean, axis=0)
    stats.register("std", np.std, axis=0)
    stats.register("min", np.min, axis=0)
    stats.register("max", np.max, axis=0)

    # Evolution
    pop, log = algorithms.eaSimple(pop, toolbox, cxpb=P_C, mutpb=P_M, ngen=MAX_ITER, stats=stats, halloffame=hof, verbose=True)

    return hof

best_sol = ga()
print(best_sol[0])
print(best_sol[0].fitness.values)
