from tsp_cities import *
import copy
import numpy as np
import math

def evaluation(data, ind):
    dist = 0
    for i in range(len(ind)-1):
        dist += math.sqrt((data[ind[i]][0] - data[ind[i+1]][0]) ** 2 + (data[ind[i]][1] - data[ind[i+1]][1]) ** 2)
        
    dist += math.sqrt((data[ind[-1]][0] - data[ind[0]][0]) ** 2 + (data[ind[-1]][1] - data[ind[0]][1]) ** 2)
    
    return dist

def generate_neighbour(current_sol):
    neighbour = copy.deepcopy(current_sol)
    swap_idx = np.random.choice(np.arange(len(current_sol)), size=2, replace=False)
    neighbour[swap_idx[0]], neighbour[swap_idx[1]] = neighbour[swap_idx[1]], neighbour[swap_idx[0]]

    return neighbour

def update_temp(T_max, rate, i):
    return T_max - i * rate

def sa():
    filename = "dj38.tsp"
    data = parse_tsp_list(filename)
    city_nb = len(data)
    T_max = 1500
    T_min = 1
    rate = 0.1
    MAX_META = 1000

    current_sol = np.random.permutation(city_nb)
    T = T_max
    meta_iter = 0
    meta_fitness = evaluation(data, current_sol)
    best = current_sol
    best_fitness = meta_fitness
    i = 1
    while T >= 1:
        # print("Temperature", T, "Best", best_fitness)
        neighbour = generate_neighbour(current_sol)
        neighbour_fitness = evaluation(data, neighbour)
        current_fitness = evaluation(data, current_sol)
        if neighbour_fitness <= current_fitness:
            current_sol = neighbour
            current_fitness = neighbour_fitness
        else:
            proba = np.exp(-(neighbour_fitness-current_fitness)/T)
            if proba > np.random.rand():
                current_sol = neighbour
                current_fitness = neighbour_fitness

        if best_fitness <= current_fitness:
            meta_iter += 1
        else:
            meta_iter = 0
            best = current_sol
            best_fitness = current_fitness
        
        if meta_iter == MAX_META:
            print("Temperature", T, "Best", best_fitness)
            meta_iter = 0
            T = update_temp(T_max, rate, i)
            i += 1


    return best, best_fitness

sol, sol_fitness = sa()
print(sol, sol_fitness)